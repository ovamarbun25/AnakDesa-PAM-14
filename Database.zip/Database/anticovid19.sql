-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2020 at 02:10 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `anticovid19`
--

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` int(11) NOT NULL,
  `judul_gejala` varchar(1024) NOT NULL,
  `isi_gejala` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `judul_gejala`, `isi_gejala`) VALUES
(1, 'Faktor Risiko Infeksi Coronavirus', 'Siapa pun dapat terinfeksi virus corona. Akan tetapi, bayi dan anak kecil, serta orang dengan kekebalan tubuh yang lemah lebih rentan terhadap serangan virus ini. Selain itu, kondisi musim juga mungkin berpengaruh. Contohnya, di Amerika Serikat, infeksi virus corona lebih umum terjadi pada musim gugur dan musim dingin. \r\n\r\nDi samping itu, seseorang yang tinggal atau berkunjung ke daerah atau negara yang rawan virus corona, juga berisiko terserang penyakit ini. Misalnya, berkunjung ke Tiongkok, khususnya kota Wuhan, yang pernah menjadi wabah COVID-19 yang bermulai pada Desember 2019.'),
(2, 'Penyebab Infeksi Coronavirus  ', 'Infeksi coronavirus disebabkan oleh virus corona itu sendiri. Kebanyakan virus corona menyebar seperti virus lain pada umumnya, seperti: \r\n\r\nPercikan air liur pengidap (bantuk dan bersin).\r\nMenyentuh tangan atau wajah orang yang terinfeksi.\r\nMenyentuh mata, hidung, atau mulut setelah memegang barang yang terkena percikan air liur pengidap virus corona. \r\nTinja atau feses (jarang terjadi)\r\nKhusus untuk COVID-19, masa inkubasi belum diketahui secara pasti. Namun, rata-rata gejala yang timbul setelah 2-14 hari setelah virus pertama masuk ke dalam tubuh. Di samping itu, metode transmisi COVID-19 juga belum diketahui dengan pasti. Awalnya, virus corona jenis COVID-19 diduga bersumber dari hewan. Virus corona COVID-19 merupakan virus yang beredar pada beberapa hewan, termasuk unta, kucing, dan kelelawar. \r\n\r\nSebenarnya virus ini jarang sekali berevolusi dan menginfeksi manusia dan menyebar ke individu lainnya. Namun, kasus di Tiongkok kini menjadi bukti nyata kalau virus ini bisa menyebar dari hewan ke manusia. Bah'),
(3, 'Gejala Infeksi Coronavirus  ', 'Virus corona bisa menimbulkan beragam gejala pada pengidapnya. Gejala yang muncul ini bergantung pada jenis virus corona yang menyerang, dan seberapa serius infeksi yang terjadi. Berikut beberapa gejala virus corona yang terbilang ringan:\r\n\r\n1.Hidung beringus.\r\n2.Sakit kepala.\r\n3.Batuk.\r\n4.Sakit tenggorokan.\r\n5.Demam.\r\n6.Merasa tidak enak badan.'),
(4, 'Diagnosis Infeksi Coronavirus  ', 'Untuk mendiagnosis infeksi virus corona, dokter akan mengawali dengan anamnesis atau wawancara medis. Di sini dokter akan menanyakan seputar gejala atau keluhan yang dialami pasien. Selain itu, dokter juga akan melakukan pemeriksaan fisik, dan pemeriksaan darah untuk membantu menegakkan diagnosis.\r\n\r\nDokter mungkin juga akan melakukan tes dahak, mengambil sampel dari tenggorokan, atau spesimen pernapasan lainnya. Untuk kasus yang diduga infeksi novel coronavirus, dokter akan melakukan swab tenggorokan, DPL, fungsi hepar, fungsi ginjal, dan PCT/CRP.'),
(5, 'Komplikasi Infeksi Coronavirus  ', 'Virus corona yang menyebabkan penyakit SARS bisa menimbulkan komplikasi pneumonia, dan masalah pernapasan parah lainnya bila tak ditangani dengan cepat dan tepat. Selain itu, SARS juga bisa menyebabkan kegagalan pernapasan, gagal jantung, hati, dan kematian.\r\n\r\nHampir sama dengan SARS, novel coronavirus juga bisa menimbulkan komplikasi yang serius. Infeksi virus ini bisa menyebabkan pneumonia, sindrom pernapasan akut, gagal ginjal, dan bahkan kem');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `umur` int(5) NOT NULL,
  `jeniskelamin` varchar(100) NOT NULL,
  `domisili` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id`, `nama`, `umur`, `jeniskelamin`, `domisili`, `username`, `password`) VALUES
(1, 'Ova Marbun', 20, 'Laki-laki', 'Sibolga', 'ovamarbun', 'ovamarbun'),
(2, 'Ova Marbun', 20, 'Laki-laki', 'Sibolga', 'ovamarbun2', 'ova123'),
(3, 'Exalanty Hutabarat', 20, 'Perempuan', 'Balige', 'exalanty', 'exalanty'),
(4, 'Ova Marbun', 20, 'laki laki', 'Sibolga', 'ovamarbun21', 'ovamarbun21'),
(5, 'Lenisa Simangunsong', 20, 'Perempuan', 'Balige', 'lenisa', 'lenisa'),
(6, 'ads', 21, 'dsa', 'asd', '123', '123'),
(7, 'Exsayudy', 19, 'Laki - laki', 'Tarutung', 'exsayudy', 'exsayudy');

-- --------------------------------------------------------

--
-- Table structure for table `tipstrik`
--

CREATE TABLE `tipstrik` (
  `id_tipstrik` int(11) NOT NULL,
  `judul_tipstrik` varchar(1024) NOT NULL,
  `isi_tipstrik` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tipstrik`
--

INSERT INTO `tipstrik` (`id_tipstrik`, `judul_tipstrik`, `isi_tipstrik`) VALUES
(1, 'Rutin Asupan Buah dan Sayuran', 'Mengonsumsi lebih banyak buah-buahan dan sayur-sayuran merupakan satu di antara pola hidup sehat, sangat penting dilakukan ketika masa pandemi virus corona saat ini.\r\n\r\nBuah dan sayur juga merupakan sumber serat, vitamin dan mineral, serta senyawa penting lain yang dibutuhkan tubuh.\r\n\r\nSimpan buah-buahan dan sayuran di lemari es untuk memungkinkan mempertahankan nutrisi yang terkandung, selain dimakan saat segar.\r\n\r\nPenting untuk memastikan anak-anak masih mendapatkan banyak buah dan sayuran dalam makanan mereka.\r\n\r\nMakan tidak sekadar jadi pemuas selera dan pengisi perut saja, melainkan juga menjadi salah satu cara untuk mempertahankan kesehatan.'),
(2, 'Bahan Makan Kering atau Kalengan Sebagai Alternatif', 'Produk segar hampir selalu merupakan pilihan terbaik, tetapi ketika tidak tersedia banyak alternatif sehat yang mudah disimpan dan disiapkan, makanan kaleng merupakan satu di antara solusi praktis.\r\n\r\nMakanan kaleng memiliki kandungan gizi yang berbeda, tergantung dari bahan dasar yang digunakan. Makanan yang diolah dan dikemas dalam kaleng memiliki daya tahan lebih lama dibandingkan makanan lainnya.\r\n\r\nMasyarakat makin membutuhkan produk makanan yang praktis, lezat, dan bisa dinikmati kapan saja. Makanan kaleng hanya perlu dihangatkan selama lima hingga 10 menit sebelum siap disantap.\r\n\r\nSayuran kalengan, seperti tomat, memang cenderung mengandung jumlah vitamin yang lebih rendah daripada produk segar, tetapi itu pilihan bagus jika dalam kondisi segar.\r\n\r\nOlahan makanan kering, seperti kacang kering, kacang-kacangan dan biji-bijian seperti lentil, kacang polong, beras, couscous atau quinoa juga bergizi.'),
(3, 'Diiringi Camilan Sehat', 'Anda sering perlu menyantap satu atau dua camilan di siang hari ketika sedang bersantai atau memiliki waktu luang bersama keluarga.\r\n\r\nBanyak penelitian yang menyatakan bahwa selain tiga makanan sehat, seperti sarapan, makan siang, dan makan malam, semua orang harus menikmati camilan sehat pada pagi dan sore hari.\r\n\r\nPilihlah opsi yang lebih sehat seperti kacang, keju, yoghurt (lebih disukai tanpa pemanis), buah cincang atau kering, telur rebus, atau pilihan sehat lain dari pada permen atau makanan ringan asin.\r\n\r\nMakanan-makanan ini bergizi, lebih mengenyangkan, dan membantu membangun kebiasaan makan sehat.'),
(4, 'Mengatur Pola Makan', 'Mengonsumsi produk segar mungkin tidak selalu memungkinkan. Anda bisa mencoba untuk memilih opsi yang lebih sehat yang mengandung lebih sedikit kandungan, seperti lemak jenuh, gula, dan garam.\r\n\r\nUsahakan juga menghindari minuman manis dan sebaliknya minum banyak air putih. Membuat olahan minuman buah atau sayuran seperti lemon, jeruk nipis, mentimun atau beri, jadi cara yang bagus untuk menambahkan sentuhan rasa ekstra dan menyehatkan bagi tubuh'),
(5, 'Isi Waktu Luang Anda Bersama Keluarga', 'Jadikan memasak dan makan menjadi bagian yang menyenangkan dan berarti dari rutinitas keluarga. Memasak dan makan bersama adalah cara yang bagus untuk menciptakan rutinitas yang sehat, memperkuat ikatan keluarga dan bersenang-senang.\r\n\r\nLibatkan anak-anak Anda dalam persiapan makanan. Anak-anak kecil dapat membantu mencuci atau menyortir makanan, sementara anak-anak yang lebih besar dapat melakukan tugas yang lebih kompleks dan membantu mengatur meja.\r\n\r\nStruktur dan rutinitas seperti itu dapat membantu mengurangi kecemasan bagi anak-anak dalam situasi yang penuh tekanan ini.\r\n\r\nDengan kegiatan yang kreatif dan produktif bersama anak, seperti memasak sangat disarankan dan tergolong sarat komunikasi sehingga memungkinkan terjalinnya kehangatan antara anggota keluarga.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tipstrik`
--
ALTER TABLE `tipstrik`
  ADD PRIMARY KEY (`id_tipstrik`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tipstrik`
--
ALTER TABLE `tipstrik`
  MODIFY `id_tipstrik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
